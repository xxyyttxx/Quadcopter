/**
  @file    main.c
  @author  tjua @ ES-SS-UESTC © 2017
  @version V1.0
  @date    20171113
  @brief   define main entry.
*/


/* Includes ------------------------------------------------------------------*/
#include "stm32f4xx.h"
#include "delay.h"
#include "usart.h"
// #include "gpio_mpu6050.h"
#include "mpu6500.h"
#include "iic1.h"

/* Private macro -------------------------------------------------------------*/
#define printf_(s, ...) printf("file:%s\tline:%d\t" s, __FILE__, __LINE__, __VA_ARGS__)

/* Private functions ---------------------------------------------------------*/

int main(void)
{

 /*!< At this stage the microcontroller clock setting is already configured,
       this is done through SystemInit() function which is called from startup
       files before to branch to application main.
       To reconfigure the default setting of SystemInit() function,
       refer to system_stm32f4xx.c file */
	delayinit();
  uart_init(38400);
  // MPU_Init();
  /* 9轴传感器初始化 */
  // void sensor9Init(void)
  iicDevInit(); /*初始化I2C1*/
  mpu6500Init(); /*MPU6500初始化*/


	for (int c=0;;c++) {
		delay(1000);
    printf("%d\r\n", c);
    s16 ax, ay, az, gx, gy, gz;
    mpu6500GetRawData(&ax, &ay, &az, &gx, &gy, &gz);
		printf("\tax_c = %d \r\n", ax);
    printf("\tay_c = %d \r\n", ay);
    printf("\taz_c = %d \r\n", az);
    printf("\tgx_c = %d \r\n", gx);
    printf("\tgy_c = %d \r\n", gy);
    printf("\tgz_c = %d \r\n", gz);
	}
}
