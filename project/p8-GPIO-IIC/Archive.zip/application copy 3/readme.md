这次，从spark11-11用了最新的MPU6050，其他都用了copy1。
居然可以，难道是我clean了的原因？
        其他文件见 copy 1 OR Archive.zip

神TM copy1 又可以了！

diff 了下 copy1 & copy3 修改了传递参数的方法，把原本的均值滤波变成低通滤波
