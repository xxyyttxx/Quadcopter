# ifndef _MPU6050_H
# define _MPU6050_H

# include "gpio_i2c.h"

typedef struct lpf_2 {
 float b0;
 float a1;
 float a2;
 float preout;
 float lastout;
}lpf_2nd;


/* 初始化MPU6050 */ uint8_t MPU_Init(void);
/* IIC连续写     */ uint8_t MPU_Write_Len(uint8_t addr,uint8_t reg,uint8_t len,uint8_t *buf);
/* IIC连续读     */ uint8_t MPU_Read_Len(uint8_t addr,uint8_t reg,uint8_t len,uint8_t *buf);
/* IIC写一个字节 */ uint8_t MPU_Write_Byte(uint8_t reg,uint8_t data);
/* IIC读一个字节 */ uint8_t MPU_Read_Byte(uint8_t reg);

uint8_t MPU_Set_Gyro_Fsr(uint8_t fsr);
uint8_t MPU_Set_Accel_Fsr(uint8_t fsr);
uint8_t MPU_Set_LPF(uint16_t lpf);
uint8_t MPU_Set_Rate(uint16_t rate);
uint8_t MPU_Set_Fifo(uint8_t sens);

short MPU_Get_Temperature(void);
uint8_t MPU_Get_Gyroscope(short *gx,short *gy,short *gz);
uint8_t MPU_Get_Accelerometer(short *ax,short *ay,short *az);
void mpu6050_send_data(short aacx,short aacy,short aacz,short gyrox,short gyroy,short gyroz);

void acc_correct(short  *ax_c,short *ay_c,short *az_c);
void gyro_correct(short *gx_c,short *gy_c,short *gz_c);

//一阶低通
float LPF_1st_Factor_Cal(float deltaT, float Fcut);
float LPF_1st(float oldData, float newData, float lpf_factor);

# endif
