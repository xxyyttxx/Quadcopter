/**
    @file    main.c
    @author  tjua @ ES-SS-UESTC © 2017
    @version V1.0
    @date    20171113
    @brief   define main entry.
*/


/* Includes ------------------------------------------------------------------*/
#include "stm32f4xx.h"
#include "delay.h"
#include "usart.h"
#include "gpio_mpu6050.h"


/* Private macro -------------------------------------------------------------*/
#define printf_(s, ...) printf("file:%s\tline:%d\t" s, __FILE__, __LINE__, __VA_ARGS__)

/* Private functions ---------------------------------------------------------*/

int main(void)
{
    
 /*!< At this stage the microcontroller clock setting is already configured, 
      this is done through SystemInit() function which is called from startup
      files before to branch to application main.
      To reconfigure the default setting of SystemInit() function, 
      refer to system_stm32f4xx.c file */
    delayinit();
    uart_init(38400);
    MPU_Init();

    for (int c=0;;c++) {
        delay(1000);
        s16 ax_c, ay_c, az_c, gx_c, gy_c, gz_c;
        MPU_Get_Gyroscope(&gx_c, &gy_c, &gz_c);
        MPU_Get_Accelerometer(&ax_c, &ay_c, &az_c);
        printf("%d\r\n", c);
        printf("\tax_c = %f \r\n", ax_c/4096.);
        printf("\tay_c = %f \r\n", ay_c/4096.);
        printf("\taz_c = %f \r\n", az_c/4096.);
        printf("\tgx_c = %f \r\n", gx_c/4096.);
        printf("\tgy_c = %f \r\n", gy_c/4096.);
        printf("\tgz_c = %f \r\n", gz_c/4096.);
    }
}
