#ifndef __GPIO_MPU6050
#define __GPIO_MPU6050
// #include "stm32f4xx.h" // u8 define in stm32f4xx.h for legacy

extern int ax_c,ay_c,az_c;
extern int gx_c,gy_c,gz_c;

uint8_t MPU_Init(void); //初始化MPU6050

short MPU_Get_Temperature(void);
uint8_t MPU_Get_Gyroscope(short *gx, short *gy, short *gz);
uint8_t MPU_Get_Accelerometer(short *ax, short *ay, short *az);
void acc_correct(void);
void gyro_correct(void);
#endif /* __GPIO_MPU6050 */
